# Release verification — v98.63.5

Source release: SA Calculator v98.63 with v98.63.2 recording fixes, v98.63.3 release-integrity correction, v98.63.4 screenshot cleanup and v98.63.5 live-currency/dock corrections.

Package identity: `1.98.63-v98.63` (Android versionCode `1098063`). The patch label is v98.63.5; the Capacitor package identity is intentionally unchanged for this patch-only release.

Checks performed:
- 364/364 automated tests pass on the final run.
- Android web bundle generated from canonical CSS source layers.
- JavaScript syntax check passes.
- Android workflow YAML syntax check passes.
- Service-worker cache namespace migrated to `sa-calculator-v98-63-live-currency-dock-fix-v98635`.
- ZIP archive integrity passes.

Not performed: hosted APK compilation, physical Android installation, target-device screenshot comparison, live currency-provider verification or performance profiling. See `RELEASE-LIMITATIONS-v98.63.md` and `SCREENSHOT-REVIEW-v98.63.5.md`.


Patch v98.63.6: stable package identity remains `1.98.63-v98.63` (Android versionCode `1098063`). The existing service-worker cache identity is retained; static assets are fetched network-first when online.
