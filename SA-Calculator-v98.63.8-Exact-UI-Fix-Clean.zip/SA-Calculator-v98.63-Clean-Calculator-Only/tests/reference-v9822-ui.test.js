const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
test('v98.27 reference calculator has exact four-column five-row key sequence', () => {
  const block = html.match(/<div class="main-keypad"[\s\S]*?<\/div>/)?.[0] || '';
  const keys = [...block.matchAll(/class="key-btn[^\"]*" data-calc="([^\"]+)"/g)].map(x => x[1]);
  assert.deepEqual(keys, ['C','±','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','=']);
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css, /grid-template-rows:repeat\(5,minmax\(0,1fr\)\)/);
});
test('Sales Tax screen exposes price, rate, calculate and green semantic results', () => {
  const b = html.match(/id="screen-salestax"[\s\S]*?<\/div>\s*<\/div>/)?.[0] || html;
  for (const id of ['tax-orig','tax-rate','tax-calculate','tax-amt','tax-total']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(html, /Item Price/); assert.match(html, /Sales Tax Rate/); assert.match(html, /Total Price/);
});
test('Loan screen accepts years and retains amortization schedule calculation IDs', () => {
  for (const id of ['loan-p','loan-r','loan-years','loan-m','loan-calculate','loan-monthly','loan-total','loan-interest','loan-amort']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(js, /readModuleNumber\('loan-years'\) \* 12/);
});
test('Tip presets and Unit Price compare controls are present and wired', () => {
  for (const id of ['tip-bill','tip-pct','tip-amt-res','tip-tot-res','tip-calculate','unit-price-compare','up-p-a','up-q-a','up-p-b','up-q-b','up-best-banner']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(html, /data-tip-preset="10"/); assert.match(html, /data-tip-preset="15"/); assert.match(html, /data-tip-preset="20"/);
  assert.match(js, /initReferenceScreenActions/);
});
test('World Time screen uses responsive city card grid and Settings remains reachable', () => {
  for (const id of ['wt-base-time','wt-zone-search','wt-zone-select','wt-add-city','wt-city-list','screen-settings']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(css, /\.reference-world-grid \{ display:grid/);
  assert.match(html, /data-bottom-nav="history"/);
});
test('v98.27 version is consistent', () => {
  assert.match(html, /1\.98\.63-v98\.63/);
  const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
  assert.equal(pkg.version,'1.98.63-v98.63');
});
test('Loan term is interpreted as years and converted to a monthly amortization schedule', () => {
  const values = {'loan-p':25000,'loan-r':5.5,'loan-years':5,'loan-grace':0,'loan-method':'total'};
  const tbody = {rows:[],replaceChildren(){this.rows=[];},appendChild(fragment){this.rows=fragment.children;}};
  const fragment = () => ({children:[],appendChild(node){this.children.push(node);}});
  const node = () => ({children:[],appendChild(child){this.children.push(child);}});
  const yearField = {querySelector:selector => selector === '.input-text' ? {} : null};
  const elements = new Map();
  const get = id => { if (id === 'loan-years') return yearField; if (!elements.has(id)) elements.set(id,{value:values[id] == null ? '' : String(values[id]),textContent:''}); return elements.get(id); };
  const document = {getElementById:get,querySelector:selector => selector === '#loan-amort tbody' ? tbody : null,createDocumentFragment:fragment,createElement:node};
  const context = {document,Number,Math,setElementText:(id,value)=>{get(id).textContent=String(value);},readModuleNumber:id=>Number(values[id]),formatResultNumber:value=>String(Number(value).toFixed(2))};
  const fn = js.match(/function calcLoan\([\s\S]*?\n\}/)?.[0];
  assert.ok(fn);
  require('node:vm').runInNewContext(`${fn};globalThis.run=calcLoan;`,context);
  context.run();
  assert.equal(tbody.rows.length,60);
  assert.equal(tbody.rows.at(-1).children.at(-1).textContent,'0.00');
});
test('Settings groups are reordered to the reference startup, sound, privacy, theme and calculator sequence', () => {
  assert.match(js,/const order = \['STARTUP PREFERENCES','SOUND & VIBRATION','PRIVACY','THEME & COLORS','CALCULATOR SETTINGS','APPEARANCE'/);
});
